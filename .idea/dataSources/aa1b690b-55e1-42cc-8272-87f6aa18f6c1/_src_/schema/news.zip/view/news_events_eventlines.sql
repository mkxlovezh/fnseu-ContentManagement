CREATE VIEW news_events_eventlines AS
  SELECT
    `A`.`news_id`   AS `news_id`,
    `A`.`event_id`  AS `event_id`,
    `B`.`eventline` AS `eventline_id`,
    `C`.`time`      AS `time`
  FROM `news`.`news_events` `A`
    JOIN `news`.`events` `B`
    JOIN `news`.`news` `C`
  WHERE ((`A`.`event_id` = `B`.`id`) AND (`A`.`news_id` = `C`.`id`));
